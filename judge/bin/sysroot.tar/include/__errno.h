#ifndef __wasm_basics___errno_h
#define __wasm_basics___errno_h

#ifdef __cplusplus
extern "C" {
#endif

/* beltgel: энэ wasm sysroot-д TLS байхгүй (libc.a дахь errno энгийн глобал). */
extern int errno;

#define errno errno

#ifdef __cplusplus
}
#endif

#endif
